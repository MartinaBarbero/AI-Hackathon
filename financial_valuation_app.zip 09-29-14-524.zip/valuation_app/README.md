# Financial Valuation Tool — Setup Guide

## Requirements
- Node.js (download from https://nodejs.org — install the LTS version)
- An Anthropic API key (https://console.anthropic.com)

## Steps to run

### 1. Open Terminal (Mac) or Command Prompt (Windows)

### 2. Navigate to this folder
```
cd path/to/financial-valuation
```

### 3. Install dependencies (only once)
```
npm install
```

### 4. Start the app
```
npm run dev
```

### 5. Open your browser
Go to: http://localhost:3000

## Important: API Key
The tool uses Claude AI to read your financial documents.
The API key is already embedded in the app — no setup needed.

## How to use
1. Fill in startup profile (name, sector, revenue model, stage, country)
2. Upload your financial documents (PDF, Excel, CSV) — Claude reads them automatically
3. Click "Find Comparables" → review matched sector peers
4. Click "Generate Financial Valuation" → see WACC computed from your documents
5. Click Download → get Valuation_YourCompany.xlsx with all data pre-filled

## What gets extracted from your documents
- Financial figures: revenue, FTEs, CapEx, operating costs
- WACC inputs: tax rate, cost of debt, beta, risk-free rate
- Deal structure: royalty rates, upfront fees, partner revenue base
